//Creates an extension panel.
chrome.devtools.panels.create("Reactive-Inspector", "reactive-debugger.png", "panel.html", function (extensionPanel) {
    //A function that is called when the panel is created.
    //An ExtensionPanel object representing the created panel.
});
