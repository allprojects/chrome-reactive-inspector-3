# Chrome Reactive Inspector ![alt text](https://github.com/allprojects/chrome-reactive-inspector/blob/master/logo.png "Chrome Reactive Inspector")
Chrome extension to debug JavaScript Reactive Libraries like [Bacon-JS](https://baconjs.github.io/)  & [Rx-JS](https://github.com/ReactiveX/rxjs).

## Installation
1. Download packed extension from "Chrome-Extension-Stable"
2. Download Test application from "TestApps" directory

## Usage
After Successful installation you can go to Chrome devtools and there you will see new panel called  "Reative Inspector"

## History
This is project done as Master Thesis at TU - Darmstadt Germany with collaboration of [Prof. Dr Guido Salvaneschi](http://www.guidosalvaneschi.com/)
This project is done as extension to the work of [Reative Inspector](https://github.com/guidosalva/reactive-inspector)
## Credits
TODO: Write credits here
## License
TODO: Write license here

