## Installation
1. Download packed extension ChromeReactiveInspector.crx
2. In your chrome browser go to "chrome://extensions/" OR "Setting and then Extensions"
3. Drag and drop ChromeReactiveInspector.crx to chrome extensions window
4. Open Test Application or Any other JS application that contains Reactive code
5. Go to Dev tools and you will see a tab named as "Reactive-Inspector" 
6. Load your Reactive application
7. Done ! 